<?php
include_once("../CONECT/conexao.php");

        $identificador = filter_input(INPUT_POST, 'my_identificador', FILTER_DEFAULT);
        $whatsapp = filter_input(INPUT_POST, 'my_celular', FILTER_DEFAULT);
        $nomemorador = filter_input(INPUT_POST, 'my_name', FILTER_DEFAULT);
        $mudaridentificador = '1';

        $token = "MTXYumi9ErkfO493tYM2oP4gDQ";
        $instance_key = "megaapi-MTXYumi9ErkfO493tYM2oP4gDQ";
        $ender = "api4.megaapi.com.br";

        $curl = curl_init();

        if(isset($_FILES['my_image']))
        {
                date_default_timezone_set("Brazil/East");

                $ext = strtolower(substr($_FILES['my_image']['name'],-4));

                $new_name = date("Y.m.d-H.i.s") . $ext;
                $dir = '../Galeria/Fotomoradores/';

                move_uploaded_file($_FILES['my_image']['tmp_name'], $dir.$new_name);
        }


        $foto = $new_name;


        $conexao = mysqli_connect ($servidor,$usuario,$senha,$dbnome);



        $SQL_EDIT_MORADOR = "UPDATE cmoradores SET fotografia = '$foto', imgcam = '$mudaridentificador' WHERE indentificador = '$identificador'";
        if (mysqli_query($conexao, $SQL_EDIT_MORADOR)){

                curl_setopt_array($curl, array(
                  CURLOPT_URL => "https://$ender/rest/sendMessage/$instance_key/text",
                  CURLOPT_RETURNTRANSFER => true,
                  CURLOPT_ENCODING => '',
                  CURLOPT_MAXREDIRS => 10,
                  CURLOPT_TIMEOUT => 0,
                  CURLOPT_FOLLOWLOCATION => true,
                  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                  CURLOPT_CUSTOMREQUEST => 'POST',
                  CURLOPT_POSTFIELDS =>'{
                    "messageData": {
                        "to": "'.$whatsapp.'@s.whatsapp.net",
                        "text": "CONFIRMAÇÃO DE CADASTRO!\n\nOlá *'.$nomemorador.'*\n\n Sua confirmação de cadastro por foto, foi afetuada com sucesso!\n\n *AGRADECEMOS O FEEDBACK*!"
                    }
                }',
                  CURLOPT_HTTPHEADER => array(
                    'Content-Type: application/json',
                    "Authorization: Bearer $token"
                  ),
                ));
        
                $response = curl_exec($curl);
        
                curl_close($curl);
        }else{
                echo "Deu erro: " . $SQL_EDIT_MORADOR . "<br>" . mysqli_error ($conexao);
        };
?>