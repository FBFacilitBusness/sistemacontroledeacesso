const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});


const txtInput = document.getElementById("input-email-liberar"),
checkBtn = document.querySelector(".sign-up-form button");
txtInput.addEventListener("keyup", () => {
    filterInput = txtInput.value.toLowerCase().replace(/[^A-Z0-9]/ig, "");
    if(filterInput) {
        return checkBtn.classList.add("active");
    }
    infoTxt.style.display = "none";
    checkBtn.classList.remove("active");
});

const button = document.querySelector(".button"),
      toast = document.querySelector(".toast")
      closeIcon = document.querySelector(".close"),
      progress = document.querySelector(".progress");

      let timer1, timer2;

      button.addEventListener("click", () => {
        toast.classList.add("active");
        progress.classList.add("active");

        timer1 = setTimeout(() => {
            toast.classList.remove("active");
        }, 5000); //1s = 1000 milliseconds

        timer2 = setTimeout(() => {
          progress.classList.remove("active");
        }, 5300);
      });
      
   closeIcon.addEventListener("click", () => {
    toast.classList.remove("active");
        
    setTimeout(() => {
      progress.classList.remove("active");
    }, 300);

    clearTimeout(timer1);
    clearTimeout(timer2);
  });
  function Mascara_rghome(Mascara_rg, input) { 

    const recebe = Mascara_rg.split("")
    const numRg = input.value.replace(/\D/g, "")
    const cursor = input.selectionStart
      
  for(let i=0; i<numRg.length; i++){
      recebe.splice(recebe.indexOf('#'), 1,numRg[i])
  }
      
  var rg = document.getElementById('doocumento')
  if (rg.value.length == 2 || rg.value.length == 6) {
      rg.value += "."
  } else if(rg.value.length == 10){
      rg.value += "-"
  }
};

function desativebutton(){
  var button = document.getElementById("desativarbotao");

  button.style.display = "none";
}
function desetivemor(){
  var morador_viz = document.getElementById("permit_morador_lib").val();

  morador_viz.style.display = "none";
}


