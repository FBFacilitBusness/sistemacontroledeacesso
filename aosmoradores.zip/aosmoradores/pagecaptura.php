<?php
include_once("../CONECT/conexao.php");
// $codidentificador = "61F04F4DF09E";
$codidentificador = filter_input(INPUT_GET, 'inviarid');

// Buscar morador no banco de dados
$sql = "SELECT * FROM cmoradores WHERE indentificador = '$codidentificador'";
$preparesql =  mysqli_query($conexao, $sql);
$dado = mysqli_fetch_assoc($preparesql);




?>

<!DOCTYPE html>
<html :class="{ 'theme-dark': dark }" x-data="data()" lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Captura de Fotografia</title>
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="./assets/css/tailwind.output.css" />
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.x.x/dist/alpine.min.js" defer></script>
    <script src="./assets/js/init-alpine.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="shortcut icon" href="../../FAVICON/iconlogo.ico" type="image/x-icon">
    <link rel="stylesheet" href="CSS/apps.css">
    <script src="JS/app.js"></script>
    <script src="JS/scrips.js"></script>
    <!-- função para mostrar e esconder div's com o select -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- script responsável por ativar webcam -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.25/webcam.min.js"></script>
   
  </head>
  <body>
    <div
      class="flex h-screen bg-gray-50 dark:bg-gray-900"
      :class="{ 'overflow-hidden': isSideMenuOpen}"
    >
      
      
      <aside
        class="fixed inset-y-0 z-20 flex-shrink-0 w-64 mt-16 overflow-y-auto bg-white dark:bg-gray-800 md:hidden"
        x-show="isSideMenuOpen"
        x-transition:enter="transition ease-in-out duration-150"
        x-transition:enter-start="opacity-0 transform -translate-x-20"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition ease-in-out duration-150"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0 transform -translate-x-20"
        @click.away="closeSideMenu"
        @keydown.escape="closeSideMenu"
      > 
      </aside>
      <div class="flex flex-col flex-1">
        <main class="h-full pb-16 overflow-y-auto">
          <div class="container px-6 mx-auto grid">
            <h2
              class="my-6 text-2xl font-semibold text-gray-700 dark:text-gray-200"
            >
              Captura de Foto
            </h2>
            <!-- CTA -->
            <a
              class="flex items-center justify-between p-4 mb-8 text-sm font-semibold text-purple-100 bg-purple-600 rounded-lg shadow-md focus:outline-none focus:shadow-outline-purple"
              href="https://unifortepatrimonial.com.br/"
            >
              <div class="flex items-center">
                <svg
                  class="w-5 h-5 mr-2"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"
                  ></path>
                </svg>
                <span>Saiba mais sobra o Grupo Uniforte</span>
              </div>
            </a>

            <!-- Big section cards -->
            <h4
              class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300"
            >
              Isntruções de uso
            </h4>
            <div
              class="px-4 py-3 mb-8 bg-white rounded-lg shadow-md dark:bg-gray-800"
            >
              <p class="text-sm text-gray-600 dark:text-gray-400">
                Olá Morador(a) <?php echo $dado['nomeMor']; ?> 
                <br>
                <br>
                Siga as intruções a baixo para confirmar seu cadastro na portaria.
                <br>
                <br>
                1° Passo - Basta clicar no botão abaixo (Selecione uma imagem).
                <br>
                <br>
                2° Passo - Selecione o método de captura.
                <br>
                (Requisitos do 2° Passo)
                <br>
                Escolha ou tire uma foto do peito para cima.
                <br>
                <br>
                3° Passo - Certifique-se de que a foto esta em otima qualidade.
                <br>
                <br>
                4° Passo e ultimo - Clique em salvar.
                
              </p>
            </div>

            <!-- Responsive cards -->
            <h4
              class="mb-4 text-lg font-semibold text-gray-600 dark:text-gray-300"
            >
              Card de Captura
            </h4>
            <div class="grid gap-6 mb-8 md:grid-cols-2 xl:grid-cols-4">
              <!-- Card -->
              <div class="flex items-center p-4 bg-white rounded-lg shadow-xs dark:bg-gray-800">
                
                <div>
                <div class="modal-dialog modal-lg">
                  <div class="modal-content">
                    <!--  action="enviadophotodomorando.php" enctype="multipart/form-data"-->
                    <form id="formAccountSettings"  method="POST" onsubmit="return false">
                        <div class="header-fotografia">
                            <div class="container-foto-visit" onclick="Botaoativarfotovisita()">
                                <div class="wrapper-foto-visit">
                                    <div class="image-foto-visit">
                                        <img id="fotovisit" src="" alt="">
                                    </div>

                                    <div class="content-foto-visit">
                                        <div class="icon-foto-visit">
                                            <ion-icon name="camera-outline"></ion-icon>
                                        </div>
                                        <div class="text-foto-visit">Selecione uma imagem</div>
                                    </div>
                                    <div id="sair-bt-foto-visit"><i class="fas fa-times"></i></div>
                                    <div class="nome-aquivo-foto-visit">Nome do Arquivo</i></div>
                                </div>
                                <label for="inputlg" for="name"></label>
                                <input id="bt-carfot-foto-visit" type="file" name="image"  hidden>
                                <input  type="text" value="<?php echo $dado['nomeMor']; ?>" name="capophoto" id="capophoto" hidden>
                                <input  type="text" id="identifi" value="<?php echo $codidentificador; ?>" name="identifi"  hidden>
                                <input  type="text" id="verificador" value="<?php echo $dado['imgcam']; ?>" name="identifi"  hidden>
                                <input  type="text" id="celular" value="<?php echo $dado['teleCel1']; ?>" name="identifi"  hidden>
                                <input  type="text" id="nomedomorador" value="<?php echo $dado['nomeMor']; ?>" name="identifi"  hidden>
                                
                            </div>
                        </div>
                      
                        <div class="modal-footer">
                            <br>
                            <input type="button" class="btn btn-default" data-bs-dismiss="modal" value="Cancelar">
                            <button type="submit" class="btn btn-info tamanhobutton">Salvar</button>
                        </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  </body>
  <script>
    $(document).ready(function() {
      $("#formAccountSettings").submit(function(f) {
        f.preventDefault();

        var ident = $("#identifi").val();
        var verify = $("#verificador").val();
        var cel = $("#celular").val();
        var nome = $("#nomedomorador").val();

        if(verify != ""){
          Swal.fire(
              "OP's!",
              'Você já tem uma imagem em nosso banco de dados ! :(',
              'error'
          )
        }else{

          let form_data = new FormData();
          let img = $("#bt-carfot-foto-visit")[0].files;
          // let imgcc = $("#imageweb")[0];

          form_data.append('my_image', img[0]);
          form_data.append('my_identificador', ident);
          form_data.append('my_celular', cel);
          form_data.append('my_name', nome);

          $.ajax({
            url: 'enviadophotodomorando.php',
            type: 'POST',
            data: form_data,
            contentType: false,
            processData: false,
            cache: false,
            success: function(data) {

                Swal.fire({
                    title: 'CADASTRO CONFIRMADO COM SUCESSO !',
                    text: 'Tudo correu bem !',
                    icon: 'success',
                    button: false,
                    timer: 2500,
                }).then(() => {
                    window.location.assign("https://unifortepatrimonial.com.br/");
                })
            }
          })
        }
      })
      

    });
  </script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-kjU+l4N0Yf4ZOJErLsIcvOU2qSb74wXpOhqTvwVx3OElZRweTnQ6d31fXEoRD1Jy" crossorigin="anonymous"></script>

    
</html>
